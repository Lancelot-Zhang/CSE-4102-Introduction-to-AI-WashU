# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        # initial score
        score = successorGameState.getScore()

        # food
        foodpos = newFood.asList()
        
        if foodpos:
            fooddis = [manhattanDistance(newPos, food) for food in foodpos]
            min_fooddis = min(fooddis)
            score += 15 / (min_fooddis + 1)

        # ghost
        for ghost, scared in zip(newGhostStates, newScaredTimes):
            ghostdist = manhattanDistance(newPos, ghost.getPosition())
        
            if scared > 0:
                score += 100 / (ghostdist + 1) # reward for scared ghost
            
            else:
                if ghostdist < 3:
                    score -= 200 # penalty for being eaten
                else:
                    score -= 5 / (ghostdist + 1) # penalty for being too close
        return score


def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"

        next_action, _ = self.minimax(gameState, 
                                      agentIndex=0, 
                                      depth=0)
        return next_action

        util.raiseNotDefined()

    def minimax(self, gameState, agentIndex, depth):

        # Terminal check
        # Stop if game ends or max depth reached
        # Return evaluation score
        if gameState.isWin() or gameState.isLose() or depth == self.depth:
            return None, self.evaluationFunction(gameState)

        # number of agents = pacman + ghosts
        num_agents = gameState.getNumAgents()

        # Determine the next agent
        next_agent = (agentIndex + 1) % num_agents

        # Increase depth only after all agents finish one round
        if next_agent == 0:
            next_depth = depth + 1
        else:
            next_depth = depth

        action_list = gameState.getLegalActions(agentIndex)

        # Pacman (max layer) (agentIndex == 0)
        if agentIndex == 0:
            init_value = float('-inf') # intial value
            best_value = init_value
            best_action = None

            for action in action_list:
                successor = gameState.generateSuccessor(agentIndex, action)
                _, value = self.minimax(successor, next_agent, next_depth)
                if value > best_value:
                    best_value = value
                    best_action = action

        # Ghost (min layer) (agentIndex >= 1)
        else:
            init_value = float('inf') # initial value
            best_value = init_value
            best_action = None

            for action in action_list:
                successor = gameState.generateSuccessor(agentIndex, action)
                _, value = self.minimax(successor, next_agent, next_depth)
                if value < best_value:
                    best_value = value
                    best_action = action

        return best_action, best_value

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        next_action, _ = self.alphabeta(gameState, 
                                        agentIndex=0, 
                                        current_depth=0, 
                                        alpha=float('-inf'), 
                                        beta=float('inf'))
        return next_action

        util.raiseNotDefined()

    def alphabeta(self, gameState, agentIndex, current_depth, alpha, beta):

        # Terminal check
        if gameState.isWin() or gameState.isLose() or current_depth == self.depth:
            return None, self.evaluationFunction(gameState)

        # number of agents
        number = gameState.getNumAgents()

        next_agent = (agentIndex + 1) % number

        if next_agent == 0:
            next_depth = current_depth + 1
        else:
            next_depth = current_depth

        # a list of legal actions for an agent
        action_list = gameState.getLegalActions(agentIndex)

        # Maximizing player: Pacman (agentIndex == 0)
        if agentIndex == 0:

            init_value = float('-inf') # initial value
            best_value = init_value
            next_action = []

            for action in action_list:

                successor = gameState.generateSuccessor(agentIndex, action)
                _, score = self.alphabeta(successor, next_agent, next_depth, alpha, beta)

                # Update 
                if score > best_value:
                    best_value = score
                    next_action = action
                alpha = max(alpha, best_value)

                # Prune
                if alpha > beta:
                    break  

            return next_action, best_value

        # Minimizing players: Ghosts (agentIndex >= 1)
        else:
            init_value = float('inf') # initial value
            best_value = init_value
            next_action = []

            for action in action_list:

                successor = gameState.generateSuccessor(agentIndex, action)
                _, score = self.alphabeta(successor, next_agent, next_depth, alpha, beta)

                # Update 
                if score < best_value:
                    best_value = score
                    next_action = action
                beta = min(beta, best_value)

                # Prune
                if alpha > beta:
                    break  

            return next_action, best_value

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"

        next_action, _ = self.expectimax(gameState, 
                                         agentIndex=0, 
                                         depth=0)
        return next_action

        util.raiseNotDefined()

    def expectimax(self, gameState, agentIndex, depth):

        # Terminal check
        if gameState.isWin() or gameState.isLose() or depth == self.depth:
            return None, self.evaluationFunction(gameState)

        # number of agents
        number = gameState.getNumAgents()

        next_agent = (agentIndex + 1) % number

        if next_agent == 0:
            next_depth = depth + 1
        else:
            next_depth = depth

        # a list of legal actions for an agent
        action_list = gameState.getLegalActions(agentIndex)

        # Pacman (max layer) (agentIndex == 0)
        if agentIndex == 0:
            init_value = float('-inf') # initial value
            best_value = init_value
            next_action = []

            for action in action_list:

                successor = gameState.generateSuccessor(agentIndex, action)

                # expectimax 
                _, score = self.expectimax(successor, next_agent, next_depth)

                # Update 
                if score > best_value:
                    best_value = score
                    next_action = action

            return next_action, best_value

        # Ghost (expectation layer) (agentIndex >= 1)
        else:

            probability = 1.0 / len(action_list) # equal probability
            expected_value = 0.0

            for action in action_list:

                successor = gameState.generateSuccessor(agentIndex, action)

                # expectimax
                _, value = self.expectimax(successor, next_agent, next_depth)

                # Calculate expected value
                expected_value += value * probability

            # expectimax has no next_action
            return None, expected_value

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <We separated this part into 3 steps. 
    The first is for food. With an initial score (variable score), we reward mildly for being close to food, and add a 
    small penalty for any remaining food. 
    For capsules, we reward mildly for being close to capsules, and penalize mildly for any remaining capsules. 
    For ghosts, we reward strongly for Pacman being close to a scared ghost, add a strong penalty for being too close to 
    a dangerous ghost (when Pacman is not under capsule effect), and add a slight penalty for Pacman being relatively 
    close to a ghost.>
    """
    "*** YOUR CODE HERE ***"

    newPos = currentGameState.getPacmanPosition()
    newFood = currentGameState.getFood()
    newCapsules = currentGameState.getCapsules()
    newGhostStates = currentGameState.getGhostStates()
    newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
    
    score = currentGameState.getScore()

    # food
    foodpos = newFood.asList()
    if foodpos:
        fooddis = [manhattanDistance(newPos, food) for food in foodpos]
        min_fooddis = min(fooddis)
        score += 15 / (min_fooddis + 1) # reward for close to food
        score -= 3 * len(foodpos) # penalty for left food
    
    # capsule
    if newCapsules:
        capsuledis = [manhattanDistance(newPos, capsule) for capsule in newCapsules]
        min_capsuledis = min(capsuledis)
        score += 30 / (min_capsuledis + 1) # reward for close to capsule
        score -= 20 * len(newCapsules) # penalty for left capsule

    # ghost
    dan_ghost = None
    scared_score = 0

    for ghost, scared in zip(newGhostStates, newScaredTimes):
        ghostdist = manhattanDistance(newPos, ghost.getPosition())

        if scared > 0:
            scared_score += (scared * (1 / (ghostdist + 1))) * 20 # strong reward for close to scared ghosts
        else:
            dan_ghost = ghostdist if dan_ghost is None else min(dan_ghost, ghostdist)

    if dan_ghost is not None:
        if dan_ghost < 3:
            return -1000 # strong penalty for being too close to a dangerous ghost
        
        score -= 5 / (dan_ghost + 1) # slight penalty for being close to a dangerous ghost

    score += scared_score
    return score


# Abbreviation
better = betterEvaluationFunction
