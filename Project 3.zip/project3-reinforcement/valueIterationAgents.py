# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import mdp, util

from learningAgents import ValueEstimationAgent
import collections

class ValueIterationAgent(ValueEstimationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A ValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100):
        """
          Your value iteration agent should take an mdp on
          construction, run the indicated number of iterations
          and then act according to the resulting policy.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
              mdp.getReward(state, action, nextState)
              mdp.isTerminal(state)
        """
        self.mdp = mdp
        self.discount = discount
        self.iterations = iterations
        self.values = util.Counter() # A Counter is a dict with default 0
        self.runValueIteration()

    def runValueIteration(self):
        # Write value iteration code here
        "*** YOUR CODE HERE ***"

        # Value Iteration
        
        for k in range(self.iterations):
            next_values = util.Counter()

            for state in self.mdp.getStates():
                
                if self.mdp.isTerminal(state):
                    next_values[state] = 0
                    continue

                actions = self.mdp.getPossibleActions(state)

                if actions:
                    max_q_value = max([self.computeQValueFromValues(state, action) for action in actions])
                    next_values[state] = max_q_value
                
            self.values = next_values


    def getValue(self, state):
        """
          Return the value of the state (computed in __init__).
        """
        return self.values[state]


    def computeQValueFromValues(self, state, action):
        """
          Compute the Q-value of action in state from the
          value function stored in self.values.
        """
        "*** YOUR CODE HERE ***"

        total_q = 0.0
        gamma = self.discount
        
        for next_state, prob in self.mdp.getTransitionStatesAndProbs(state, action):

            reward= self.mdp.getReward(state, action, next_state)
            
            future_utility = gamma * self.values[next_state]
            
            weighted_score = prob * (reward + future_utility)

            total_q += weighted_score
            
        return total_q

        util.raiseNotDefined()

    def computeActionFromValues(self, state):
        """
          The policy is the best action in the given state
          according to the values currently stored in self.values.

          You may break ties any way you see fit.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return None.
        """
        "*** YOUR CODE HERE ***"

        if self.mdp.isTerminal(state):
            return None
            
        possible_actions = self.mdp.getPossibleActions(state)
        
        if len(possible_actions) == 0:
            return None
        
        action_scores = {}
        for act in possible_actions:
            action_scores[act] = self.computeQValueFromValues(state, act)
        
        return max(action_scores, key=action_scores.get)

        util.raiseNotDefined()

    def getPolicy(self, state):
        return self.computeActionFromValues(state)

    def getAction(self, state):
        "Returns the policy at the state (no exploration)."
        return self.computeActionFromValues(state)

    def getQValue(self, state, action):
        return self.computeQValueFromValues(state, action)

class AsynchronousValueIterationAgent(ValueIterationAgent):
    """
        * Please read learningAgents.py before reading this.*

        An AsynchronousValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs cyclic value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 1000):
        """
          Your cyclic value iteration agent should take an mdp on
          construction, run the indicated number of iterations,
          and then act according to the resulting policy. Each iteration
          updates the value of only one state, which cycles through
          the states list. If the chosen state is terminal, nothing
          happens in that iteration.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
              mdp.getReward(state)
              mdp.isTerminal(state)
        """
        ValueIterationAgent.__init__(self, mdp, discount, iterations)

    def runValueIteration(self):
        "*** YOUR CODE HERE ***"

        all_states = self.mdp.getStates()
        num_states = len(all_states)

        for k in range(self.iterations):

            state = all_states[k % num_states]
            if self.mdp.isTerminal(state):
                continue

            legal_actions = self.mdp.getPossibleActions(state)
            if legal_actions:
                best_val = max(self.computeQValueFromValues(state, action) for action in legal_actions)
                
                self.values[state] = best_val

class PrioritizedSweepingValueIterationAgent(AsynchronousValueIterationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A PrioritizedSweepingValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs prioritized sweeping value iteration
        for a given number of iterations using the supplied parameters.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100, theta = 1e-5):
        """
          Your prioritized sweeping value iteration agent should take an mdp on
          construction, run the indicated number of iterations,
          and then act according to the resulting policy.
        """
        self.theta = theta
        ValueIterationAgent.__init__(self, mdp, discount, iterations)

    def runValueIteration(self):
        "*** YOUR CODE HERE ***"

        incoming_edges = {}
        all_states = self.mdp.getStates()

        # Predecessors Graph
        for s in all_states:
            incoming_edges[s] = set()

        for s in all_states:
            if self.mdp.isTerminal(s): 
                continue
            
            for action in self.mdp.getPossibleActions(s):
                for next_s, prob in self.mdp.getTransitionStatesAndProbs(s, action):
                    if prob > 0:
                        incoming_edges[next_s].add(s)

        def get_diff_and_max_q(target_state):

            if self.mdp.isTerminal(target_state):
                return 0.0, 0.0
            
            possible_actions = self.mdp.getPossibleActions(target_state)
            if not possible_actions:
                return 0.0, 0.0
            
            best_q = max(self.computeQValueFromValues(target_state, a) for a in possible_actions)
            current_diff = abs(self.values[target_state] - best_q)
            
            return current_diff, best_q

        # Initialize the priority queue
        pq = util.PriorityQueue()

        for s in all_states:
            if self.mdp.isTerminal(s): 
                continue
            diff, _ = get_diff_and_max_q(s)
            pq.update(s, -diff)

        # Execute iterations
        for _ in range(self.iterations):
            if pq.isEmpty():
                break

            s = pq.pop()

            if not self.mdp.isTerminal(s):
                _, new_value = get_diff_and_max_q(s)
                self.values[s] = new_value

            for p in incoming_edges[s]:
                pred_diff, _ = get_diff_and_max_q(p)
                if pred_diff > self.theta:
                    pq.update(p, -pred_diff)